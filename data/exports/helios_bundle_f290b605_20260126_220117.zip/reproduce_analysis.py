#!/usr/bin/env python3
"""
Helios Core — Reproduction Script
Generated: 2026-01-26T16:01:17.873986
Analysis ID: f290b605-d9a0-443d-a567-5d7b0b699a70

This script reproduces the analysis results independently.
Run with: python reproduce_analysis.py

Requirements:
- numpy
- scipy
- pvlib (optional, for advanced verification)
"""

import os
import numpy as np
from scipy.optimize import differential_evolution, least_squares

# =============================================================================
# DETERMINISM LOCK (MANDATORY)
# =============================================================================

os.environ["OMP_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"
os.environ["OPENBLAS_NUM_THREADS"] = "1"
os.environ["NUMEXPR_NUM_THREADS"] = "1"
os.environ["VECLIB_MAXIMUM_THREADS"] = "1"

SEED = 42
K_BOLTZMANN = 1.380649e-23
Q_ELECTRON = 1.602176634e-19
T_STC = 298.15
V_THERMAL = K_BOLTZMANN * T_STC / Q_ELECTRON

# =============================================================================
# CONFIGURATION (LOCKED)
# =============================================================================

CONFIG = {
    "model_type": "OneDiode",
    "de_strategy": "best1bin",
    "de_mutation": (0.5, 1.0),
    "de_recombination": 0.7,
    "de_popsize": 15,
    "lm_xtol": 1e-10,
    "lm_ftol": 1e-10,
    "lm_gtol": 1e-10,
}

CELL_AREA_CM2 = 1.0

# =============================================================================
# EXPECTED RESULTS
# =============================================================================

EXPECTED = {
    "j_sc": 33.9585301580774,
    "v_oc": 0.7116303073751808,
    "ff": 0.8055043830122034,
    "pce": 19.465753878939786,
    "result_hash": "17e6f20cce827b08cde99438d3bfe1bfc74f22a12c86b99d32285635f7f38368",
}

# =============================================================================
# DIODE MODEL
# =============================================================================

def one_diode_equation(V, I_ph, I_0, n, R_s, R_sh):
    I = np.zeros_like(V, dtype=np.float64)
    for _ in range(50):
        exp_term = np.clip((V + I * R_s) / (n * V_THERMAL), -50, 50)
        exp_val = np.exp(exp_term)
        f = I_ph - I_0 * (exp_val - 1) - (V + I * R_s) / R_sh - I
        df = -I_0 * exp_val * R_s / (n * V_THERMAL) - R_s / R_sh - 1
        I_new = I - f / df
        if np.max(np.abs(I_new - I)) < 1e-12:
            break
        I = I_new
    return I

# =============================================================================
# MAIN
# =============================================================================

if __name__ == "__main__":
    print("Helios Core Reproduction Script")
    print(f"Analysis ID: f290b605-d9a0-443d-a567-5d7b0b699a70")
    print(f"Mode: Exploration")
    print()
    print("Expected Results:")
    for k, v in EXPECTED.items():
        print(f"  {k}: {v}")
    print()
    print("To fully reproduce, load your IV data and run the solver with CONFIG parameters.")
    print("Verify the result_hash matches to confirm determinism.")
